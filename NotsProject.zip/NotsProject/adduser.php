<?php
// Php logic to add a user 
// Mainly intrection with db.
$username=$_POST['username'];
$password=$_POST['password'];
$photo=$_FILES['image']['tmp_name'];
$size=$_FILES['image']['size'];

// Check That the image should be in jpeg formet.
if($_FILES['image']['type'] != "image/jpeg")
  {
      header('location:nojpeg.php');
  }
  // Add backslashes to the image content to store in db.
$imageContent=addslashes(file_get_contents($photo));

//Stablish connection
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'nots');
$q="select name from user where name='$username' and password='$password'";
$r=mysqli_query($con,$q);
$num=mysqli_num_rows($r);
if($num==1)
  {
    // If the user and password exist then it will throw you to the upexist.php page 
    // Which will throw you to signpupage.
     header('location:upexists.php');
  }
else
   {
       $qu="insert into user (name,password,photo) values ('$username','$password','$imageContent')";
       $re=mysqli_query($con,$qu);
       if($re==1)
         {
          //  If everything is all right then the account will be created and you will 
          // be thro to conform.php page where you will be redirected to the login page 
          // where you can log in.
             header('location:conform.php');
         }
       else
        {
          // If some errow occors then you will be thrown to that page
             header('location:nojpeg.php');
         }
   }

mysqli_close($con);
?>