<?php
session_start();
session_destroy();
?>
<!-- If you are not a authorised user then only you will come to this page 
     and you will be thrown to loginpage after three seconds. -->

<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="css/notsstyle.css" rel="stylesheet">
        <link rel="stylesheet" href="node_modules\bootstrap\dist\css\bootstrap.min.css">
        
        <script type="text/javascript">
            function Redirect() {
               window.location="http://localhost/notsProject/nots.html";
            }
            
            setTimeout('Redirect()', 3000);
      </script>

    </head>
    <body>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                   <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                        <li class="nav-item dropdown">
                          <a  class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:  white;">
                             Contect Us
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <h5 class="dropdown-item">8770734350</h5>
                            <div class="dropdown-divider"></div>
                            <p class="dropdown-item">indrakumarmhaski@gmail.com</p>
                          </div>
                        </li>
                      </ul>
                      <h4 style="color:aqua;">Enjoy Nots</h4>
                    </div>
                  </nav>
    <div class="container outer-body">
              <h3 id="heading">UserName and Password Does not exist!</h3>
        <div id="form-container">
             

            


        </div>


    </div>
    
    <footer>
        <blockquote class="blockquote">
            <p class="mb-0">You don't need to remember improtrant things, let them remembered by NOTS.</p>
            <div style="float: right; margin-right:5px; background-color:gainsboro;" class="blockquote-footer ikm ">Mr. <cite title="Source Title">Indra Kumar Mhaski</cite></div>
          </blockquote>
    </footer>
        <script src="jquery\jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>
    </body>
</html>