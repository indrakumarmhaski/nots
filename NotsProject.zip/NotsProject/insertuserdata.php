<?php
session_start();
$not=$_POST['nots'];
$date=date("Y-m-d");
$username=$_SESSION['username'];
$password=$_SESSION['password'];
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'nots');
$q="insert into userdata(name,password,nots,time) values ('$username','$password','$not','$date')";
mysqli_query($con,$q);
mysqli_close($con);
header('location:userpage.php');

?>